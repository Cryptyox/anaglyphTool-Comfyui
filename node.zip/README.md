# anaglyphTool-Comfyui
This Comfyui custom node creates an anaglyph image from a color and depth map input. It achieves high speeds suitable for video to anaglyph conversion.
